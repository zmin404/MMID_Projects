<?php
#-----------------------------------------
#	RT-Theme vc_functions.php
#-----------------------------------------

if ( class_exists( 'WPBakeryVisualComposer' ) ){

}
?>